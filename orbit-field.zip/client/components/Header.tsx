import { Link } from "react-router-dom";
import { Briefcase } from "lucide-react";

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-blue-700">
              <Briefcase className="h-6 w-6 text-white" />
            </div>
            <Link to="/" className="text-xl font-bold text-gray-900">
              CareerBoost
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Home
            </Link>
            <Link
              to="/enhance-resume"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Enhance Resume
            </Link>
            <Link
              to="/cover-letter"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Cover Letter
            </Link>
            <Link
              to="/job-fit"
              className="text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors"
            >
              Job Fit
            </Link>
          </nav>

          <Link
            to="/enhance-resume"
            className="hidden sm:inline-flex px-5 py-2 text-sm font-semibold rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 transition-all shadow-sm hover:shadow-md"
          >
            Get Started
          </Link>
        </div>
      </div>
    </header>
  );
}
